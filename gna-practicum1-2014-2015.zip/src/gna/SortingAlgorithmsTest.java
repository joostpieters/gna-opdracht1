package gna;

import static org.junit.Assert.*;
import libpract.SortingAlgorithm;

import org.junit.Test;

/**
 * Tests that test whether the implementations of the sorting algorithms do sort.
 */
public class SortingAlgorithmsTest {

	@Test
	public void my_first_test() {
		fail("Je moet nog testen schrijven"); // TODO
	}

}
